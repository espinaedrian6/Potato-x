# POTATO X — Ultimate Android Game Booster

[![Android CI Build - POTATO X](https://github.com/aistudio/potatox/actions/workflows/android-build.yml/badge.svg)](.github/workflows/android-build.yml)
[![Platform](https://img.shields.io/badge/Platform-Android%208.0%2B%20(API%2026%2B)-brightgreen.svg)]()
[![Target](https://img.shields.io/badge/Target-Android%2012%20(OPPO%20A17k)-red.svg)]()
[![Design](https://img.shields.io/badge/Design-ASUS%20ROG%20Armoury%20Crate-crimson.svg)]()
[![Offline](https://img.shields.io/badge/Privacy-100%25%20Offline-blue.svg)]()

**POTATO X** is a high-performance native Android gaming control center engineered for entry-level and budget smartphones, with priority optimization for the **OPPO A17k running Android 12 (ColorOS 12.1, MediaTek Helio G35, 3GB RAM, 64GB storage, 60 Hz display)**.

Inspired by the visual and functional aesthetics of **ASUS ROG Armoury Crate**, POTATO X combines aggressive cybernetic styling, neon telemetry gauges, and low-latency hardware monitors with strictly **real, honest Android engineering**.

---

## ⚡ Core Philosophy & Technical Honesty

Unlike generic "game booster" apps on Google Play that claim to magically double frame rates, modify game binary code, or inject impossible 120Hz refresh modes on 60Hz screens, **POTATO X adheres to strict technical transparency**:

- **No Fabricated Statistics**: Hardware memory readings, battery thermals, CPU cores, and storage usage are measured directly from native Android APIs (`ActivityManager.MemoryInfo`, `BatteryManager`, `StatFs`, `Display.supportedModes`).
- **Honest FPS Transparency**: Android does not expose other applications' rendering frame rates without root or platform signature keys. POTATO X explicitly notifies the user rather than faking an FPS counter.
- **Hardware Refresh Rate Integrity**: If your device (such as the OPPO A17k) physically contains a 60 Hz display panel, POTATO X clearly displays 60 Hz as the maximum hardware capability and never claims to "unlock 90Hz or 120Hz".
- **Safe, Sandbox-Compliant Optimizations**: Trims temporary application caches, invokes garbage collection recommendations (`System.gc()`), and safely requests background process trimming via official APIs (`killBackgroundProcesses`). It never corrupts game files or risks game bans.
- **100% Offline & Private**: Zero analytics trackers, zero external cloud dependencies, zero account requirements.

---

## 🎮 Feature Modules

### 1. ROG Gaming Dashboard
- **Cyber HUD Gauges**: Circular animated speedometers displaying real-time RAM usage percentage, allocated MB, battery health, Celsius temperature, and charging status.
- **Hardware Profile**: Automatically identifies device manufacturer, chipset architecture (arm64-v8a), core count, and display refresh mode.
- **Gaming Mode Switcher**:
  - `Balanced Mode`: Standard scheduling for everyday play.
  - `Performance Mode`: Aggressive CPU foreground prioritization and background telemetry suspension.
  - `Battery Saver`: Throttled polling intervals to conserve power.
  - `Potato Mode`: Ultra-lightweight UI rendering engineered for 2GB–3GB RAM devices, disabling heavy animations and maximizing available memory for foreground games.
- **Quick Optimize**: Immediate one-tap cache cleaning and background task trimming with feedback reporting.

### 2. Game Library & App Scanner
- Scans installed applications using Android launcher intent queries (`Intent.ACTION_MAIN + CATEGORY_LAUNCHER`).
- Zero broad `QUERY_ALL_PACKAGES` violation (compliant with Google Play policies).
- Search bar, add/remove games from library, favorite toggles, and play counter tracking.
- Pre-configured profiles and quick-launch shortcuts.

### 3. Game Booster Panel & Floating HUD
- Real-time network latency test (ICMP/TCP ping probe).
- Gaming session stopwatch with persistent HUD tracking.
- Optional draggable floating HUD overlay (`SYSTEM_ALERT_WINDOW`) displaying live RAM, temperature, and session time directly over your games.
- Quick system shortcuts: Gaming Do Not Disturb mode and system brightness controls.

### 4. Color Lab (Optical Enhancement Filter)
- Selectable gaming visual profiles:
  - *Original* (Natural display)
  - *Gaming Red* (High-contrast night filter)
  - *Gaming Blue* (Glare reduction cyan filter)
  - *Gaming Purple* (Neon ROG contrast)
  - *Gaming Green* (Tactical visibility for foliage/battle royales)
  - *Warm* (Eye-strain blue light filter)
  - *Cool* (Crisp daylight outdoor filter)
  - *High Contrast* (Vignette contrast enhancement)
  - *Custom Profile*
- Real-time in-app simulation preview with adjustable intensity slider (10% to 100%).
- Transparent touch-through screen overlay that preserves touch input while gaming.

### 5. Refresh Rate Control
- Detects display capabilities via `Display.supportedModes`.
- Validates whether the hardware supports dynamic switching or is hardware-locked to 60 Hz.
- Direct shortcut to Android system display settings.

### 6. Potato Graphics System
- Verified in-game step-by-step graphical guides for demanding competitive titles:
  1. **Mobile Legends: Bang Bang** (Smooth graphics, damage text disabling, team fight stutter prevention).
  2. **Call of Duty: Mobile** (Low graphics + High FPS priority, real-time shadow disabling, shader preloading).
  3. **Roblox** (Manual graphics slider 1–2, resolution scaling, performance stats overlay).
  4. **PUBG Mobile / BGMI** (Smooth style, extreme framerate unlock, anti-aliasing disabling).
  5. **Minecraft** (Render distance 6–8 chunks, fancy leaves disabling, smooth lighting off).
  6. **Garena Free Fire** (High FPS normal, resource cache purging).

### 7. Optional Shizuku Module (Elevated ADB Diagnostics)
- **Zero-Crash Architecture**: Completely optional. If Shizuku is not installed, the app cleanly displays `"Shizuku not connected — Basic features remain available."`
- Official `dev.rikka.shizuku:api` integration.
- Connection status, permission status, wireless debugging pairing guide for Android 11 & 12.
- Safe elevated operations: low-overhead kernel memory allocation telemetry without root.

### 8. Installation & Permissions Manager
- Guided setup for Floating Overlay (`SYSTEM_ALERT_WINDOW`), Battery Optimization exemption, Usage Access, and Notifications.
- Built-in OPPO A17k / Android 12 compatibility verification.

---

## 🛠️ Tech Stack & Architecture

- **Language**: Kotlin 2.2+
- **UI Toolkit**: Jetpack Compose with Material 3 and custom ROG design system
- **Architecture**: Clean MVVM (Model-View-ViewModel) with Kotlin Coroutines & StateFlow
- **Local Persistence**: Android Jetpack Room Database (`androidx.room`)
- **IPC & System Services**: Android WindowManager, ActivityManager, BatteryManager, ConnectivityManager
- **Elevated IPC**: Shizuku API (v13.1.5)
- **Build System**: Gradle Kotlin DSL (`build.gradle.kts`)

---

## 🚀 Building & Running

### Prerequisites
- Android Studio Ladybug / Meerkat or later
- JDK 17 or JDK 21
- Android SDK 36 (compileSdk 36, minSdk 24, targetSdk 36)

### Build Debug APK via Terminal
```bash
./gradlew assembleDebug
```
The compiled APK will be output to:
`app/build/outputs/apk/debug/app-debug.apk`

### Run Local Unit & Robolectric Tests
```bash
./gradlew testDebugUnitTest
```

---

## 🤖 GitHub Actions CI/CD

POTATO X includes a complete automated CI workflow located at `.github/workflows/android-build.yml`.
Every push and pull request runs:
1. Repository checkout.
2. Gradle wrapper validation.
3. JDK 17 environment setup.
4. Android SDK installation.
5. Unit and Robolectric test execution.
6. Debug APK compilation (`assembleDebug`).
7. Automatic upload of `app-debug.apk` as a downloadable GitHub Actions artifact.

---

## 📄 License
POTATO X is open-source software built for the Android gaming community.
