package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.ColorProfile
import com.example.data.model.GamingMode
import com.example.data.repository.SystemStatsRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun verifyAppNameString() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("POTATO X", appName)
    }

    @Test
    fun verifySystemStatsRepository() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repository = SystemStatsRepository(context)
        val stats = repository.getRealDeviceStats()

        assertNotNull(stats)
        assertTrue(stats.totalRamMb >= 0)
        assertTrue(stats.cpuCoreCount >= 1)
        assertNotNull(stats.hardwareModel)
        assertTrue(stats.supportedRefreshRates.isNotEmpty())
    }

    @Test
    fun verifyGamingModes() {
        assertEquals(4, GamingMode.values().size)
        val potatoMode = GamingMode.POTATO
        assertEquals("Potato Mode", potatoMode.title)
        assertTrue(potatoMode.description.contains("OPPO A17k"))
    }

    @Test
    fun verifyColorProfiles() {
        assertTrue(ColorProfile.values().isNotEmpty())
        assertEquals("Original", ColorProfile.ORIGINAL.title)
        assertEquals(0L, ColorProfile.ORIGINAL.colorHex)
    }
}
