package com.example.ui.screens.shizuku

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.PotatoXApplication
import com.example.data.repository.ShizukuStatus
import com.example.ui.components.RogButton
import com.example.ui.components.RogCard
import com.example.ui.components.RogHeader
import com.example.ui.components.RogOutlinedButton
import com.example.ui.theme.RogBlack
import com.example.ui.theme.RogCardBorder
import com.example.ui.theme.RogCharcoal
import com.example.ui.theme.RogCyan
import com.example.ui.theme.RogGreen
import com.example.ui.theme.RogPurple
import com.example.ui.theme.RogRed
import com.example.ui.theme.RogSurface
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun ShizukuScreen() {
    val context = LocalContext.current
    val app = context.applicationContext as PotatoXApplication
    val shizukuManager = app.shizukuManager
    val state by shizukuManager.state.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(RogBlack)
            .padding(horizontal = 16.dp)
            .testTag("shizuku_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            RogHeader(
                title = "Shizuku Module",
                subtitle = "Optional elevated ADB diagnostics (Root NOT required)",
                actionIcon = {
                    IconButton(onClick = { shizukuManager.checkStatus() }) {
                        Icon(Icons.Default.Refresh, contentDescription = "Refresh Status", tint = RogCyan)
                    }
                }
            )
        }

        // Connection Status Card
        item {
            val statusColor = when (state.status) {
                ShizukuStatus.AUTHORIZED -> RogGreen
                ShizukuStatus.PERMISSION_DENIED -> Color(0xFFFFD700)
                ShizukuStatus.SERVICE_STOPPED -> RogPurple
                ShizukuStatus.NOT_INSTALLED -> TextMuted
            }

            val statusTitle = when (state.status) {
                ShizukuStatus.AUTHORIZED -> "SHIZUKU CONNECTED & AUTHORIZED"
                ShizukuStatus.PERMISSION_DENIED -> "SHIZUKU RUNNING (PERMISSION REQUIRED)"
                ShizukuStatus.SERVICE_STOPPED -> "SHIZUKU INSTALLED (SERVICE STOPPED)"
                ShizukuStatus.NOT_INSTALLED -> "SHIZUKU NOT INSTALLED"
            }

            RogCard(
                modifier = Modifier.fillMaxWidth(),
                borderColor = statusColor.copy(alpha = 0.7f)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(12.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(statusColor)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = statusTitle,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Black,
                                letterSpacing = 0.5.sp
                            ),
                            color = statusColor
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = state.statusMessage,
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextPrimary
                    )

                    Spacer(modifier = Modifier.height(14.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        if (state.status == ShizukuStatus.PERMISSION_DENIED) {
                            RogButton(
                                text = "Request Permission",
                                onClick = { shizukuManager.requestPermission() },
                                color = RogGreen,
                                testTag = "shizuku_request_permission"
                            )
                        } else if (state.status == ShizukuStatus.NOT_INSTALLED) {
                            RogButton(
                                text = "Get Shizuku",
                                onClick = { shizukuManager.openShizukuDownload() },
                                color = RogCyan
                            )
                        } else if (state.status == ShizukuStatus.SERVICE_STOPPED) {
                            RogButton(
                                text = "Open Shizuku App",
                                onClick = { shizukuManager.openShizukuApp() },
                                color = RogPurple
                            )
                        }

                        RogOutlinedButton(
                            text = "Refresh",
                            onClick = { shizukuManager.checkStatus() },
                            color = TextSecondary
                        )
                    }
                }
            }
        }

        // Safety Guarantee Card
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF161925))
                    .border(1.dp, RogCardBorder, RoundedCornerShape(8.dp))
                    .padding(14.dp)
            ) {
                Row(verticalAlignment = Alignment.Top) {
                    Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = RogGreen, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "ZERO-RISK ARCHITECTURE",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = RogGreen
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Potato X operates 100% safely without Shizuku. If Shizuku is connected, Potato X only calls official, non-destructive platform APIs to query detailed memory allocations. No arbitrary shell commands or root exploits are ever executed.",
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                            color = TextSecondary
                        )
                    }
                }
            }
        }

        // Supported Features with Shizuku
        item {
            RogHeader(
                title = "Elevated Diagnostic Capabilities",
                subtitle = "Enhanced inspection features unlocked when authorized"
            )

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                state.supportedFeatures.forEach { feature ->
                    RogCard(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (state.isAuthorized) Icons.Default.CheckCircle else Icons.Default.Lock,
                                contentDescription = null,
                                tint = if (state.isAuthorized) RogGreen else TextMuted,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = feature,
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                                color = if (state.isAuthorized) TextPrimary else TextSecondary
                            )
                        }
                    }
                }
            }
        }

        // Step by step setup guide
        item {
            RogHeader(
                title = "Setup Guide for Android 11 & 12",
                subtitle = "How to pair Shizuku via Wireless Debugging"
            )

            RogCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp)) {
                    GuideStep(number = "1", text = "Install the official Shizuku app from Google Play or GitHub releases.")
                    GuideStep(number = "2", text = "Enable Developer Options on your phone (Tap 'Build Number' 7 times in About Phone).")
                    GuideStep(number = "3", text = "In Developer Options, turn on 'Wireless Debugging' and connect to Wi-Fi.")
                    GuideStep(number = "4", text = "Open Shizuku -> tap 'Pairing' -> enter the 6-digit Wi-Fi code.")
                    GuideStep(number = "5", text = "Start Shizuku service, then return to Potato X and tap 'Request Permission'.")
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
fun GuideStep(number: String, text: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            modifier = Modifier
                .size(20.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(RogSurface),
            contentAlignment = Alignment.Center
        ) {
            Text(text = number, style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold), color = RogCyan)
        }
        Spacer(modifier = Modifier.width(8.dp))
        Text(text = text, style = MaterialTheme.typography.bodySmall, color = TextPrimary)
    }
}
