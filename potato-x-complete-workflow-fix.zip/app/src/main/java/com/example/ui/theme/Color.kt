package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val RogBlack = Color(0xFF0A0A0E)
val RogCharcoal = Color(0xFF13141B)
val RogSurface = Color(0xFF1A1C26)
val RogSurfaceVariant = Color(0xFF232635)
val RogCardBorder = Color(0xFF32364B)
val RogCardBorderActive = Color(0xFFFF003C)

val RogRed = Color(0xFFFF003C)
val RogRedHover = Color(0xFFFF2E5B)
val RogRedGlow = Color(0x44FF003C)
val RogRedDark = Color(0xFF7A001D)

val RogCyan = Color(0xFF00E5FF)
val RogCyanGlow = Color(0x3300E5FF)
val RogPurple = Color(0xFFA855F7)
val RogPurpleGlow = Color(0x33A855F7)
val RogGreen = Color(0xFF00E676)
val RogAmber = Color(0xFFFF9100)

val TextPrimary = Color(0xFFF5F6F8)
val TextSecondary = Color(0xFFA0A6B5)
val TextMuted = Color(0xFF656B7D)
