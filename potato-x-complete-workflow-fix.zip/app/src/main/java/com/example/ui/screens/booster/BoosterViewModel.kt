package com.example.ui.screens.booster

import android.app.Application
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.PotatoXApplication
import com.example.data.model.DeviceStats
import com.example.data.model.GamingMode
import com.example.service.GamingOverlayService
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Locale

class BoosterViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as PotatoXApplication
    private val statsRepo = app.systemStatsRepository

    private val _deviceStats = MutableStateFlow(statsRepo.getRealDeviceStats())
    val deviceStats: StateFlow<DeviceStats> = _deviceStats.asStateFlow()

    private val _selectedMode = MutableStateFlow(GamingMode.BALANCED)
    val selectedMode: StateFlow<GamingMode> = _selectedMode.asStateFlow()

    private val _networkPingMs = MutableStateFlow<Int?>(null)
    val networkPingMs: StateFlow<Int?> = _networkPingMs.asStateFlow()

    private val _isTestingPing = MutableStateFlow(false)
    val isTestingPing: StateFlow<Boolean> = _isTestingPing.asStateFlow()

    // Gaming session timer
    private val _sessionElapsedSeconds = MutableStateFlow(0L)
    val sessionElapsedSeconds: StateFlow<Long> = _sessionElapsedSeconds.asStateFlow()

    private val _isSessionActive = MutableStateFlow(false)
    val isSessionActive: StateFlow<Boolean> = _isSessionActive.asStateFlow()

    private val _isOverlayActive = MutableStateFlow(false)
    val isOverlayActive: StateFlow<Boolean> = _isOverlayActive.asStateFlow()

    private var sessionJob: Job? = null
    private var telemetryJob: Job? = null

    init {
        startTelemetryLoop()
        testNetworkPing()
    }

    private fun startTelemetryLoop() {
        telemetryJob?.cancel()
        telemetryJob = viewModelScope.launch {
            while (isActive) {
                try {
                    _deviceStats.value = statsRepo.getRealDeviceStats()
                } catch (ignored: Exception) {}
                delay(2000L)
            }
        }
    }

    fun setGamingMode(mode: GamingMode) {
        _selectedMode.value = mode
    }

    fun startSession() {
        if (_isSessionActive.value) return
        _isSessionActive.value = true
        sessionJob?.cancel()
        sessionJob = viewModelScope.launch {
            while (isActive && _isSessionActive.value) {
                delay(1000L)
                _sessionElapsedSeconds.value += 1
            }
        }
    }

    fun pauseSession() {
        _isSessionActive.value = false
        sessionJob?.cancel()
    }

    fun resetSession() {
        _isSessionActive.value = false
        sessionJob?.cancel()
        _sessionElapsedSeconds.value = 0L
    }

    fun getFormattedSessionTime(): String {
        val totalSecs = _sessionElapsedSeconds.value
        val hours = totalSecs / 3600
        val mins = (totalSecs % 3600) / 60
        val secs = totalSecs % 60
        return if (hours > 0) {
            String.format(Locale.US, "%02d:%02d:%02d", hours, mins, secs)
        } else {
            String.format(Locale.US, "%02d:%02d", mins, secs)
        }
    }

    fun testNetworkPing() {
        if (_isTestingPing.value) return
        viewModelScope.launch {
            _isTestingPing.value = true
            val ping = statsRepo.measureNetworkPing()
            _networkPingMs.value = if (ping > 0) ping else null
            _isTestingPing.value = false
        }
    }

    fun toggleOverlay(): Boolean {
        if (!Settings.canDrawOverlays(app)) {
            return false // Needs permission
        }
        val newState = !_isOverlayActive.value
        _isOverlayActive.value = newState
        if (newState) {
            GamingOverlayService.start(app)
        } else {
            GamingOverlayService.stop(app)
        }
        return true
    }

    fun openOverlaySettings() {
        val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION).apply {
            data = android.net.Uri.parse("package:${app.packageName}")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            app.startActivity(intent)
        } catch (ignored: Exception) {}
    }

    fun openDndSettings() {
        val nm = app.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        if (nm != null && !nm.isNotificationPolicyAccessGranted) {
            val intent = Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            try {
                app.startActivity(intent)
            } catch (ignored: Exception) {}
        }
    }

    override fun onCleared() {
        super.onCleared()
        telemetryJob?.cancel()
        sessionJob?.cancel()
    }
}
