package com.example.ui.screens.library

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.GameEntity
import com.example.data.model.InstalledAppInfo
import com.example.ui.components.RogButton
import com.example.ui.components.RogCard
import com.example.ui.components.RogHeader
import com.example.ui.components.RogOutlinedButton
import com.example.ui.theme.RogBlack
import com.example.ui.theme.RogCardBorder
import com.example.ui.theme.RogCardBorderActive
import com.example.ui.theme.RogCharcoal
import com.example.ui.theme.RogCyan
import com.example.ui.theme.RogGreen
import com.example.ui.theme.RogRed
import com.example.ui.theme.RogSurface
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GameLibraryScreen(
    viewModel: LibraryViewModel = viewModel(),
    onOpenPresetGuide: (String) -> Unit
) {
    val selectedTab by viewModel.selectedTab.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val savedGames by viewModel.filteredSavedGames.collectAsState()
    val installedApps by viewModel.filteredInstalledApps.collectAsState()
    val isScanning by viewModel.isScanning.collectAsState()
    val suggestedGuides = viewModel.suggestedGuides

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(RogBlack)
            .padding(horizontal = 16.dp)
            .testTag("game_library_screen")
    ) {
        Spacer(modifier = Modifier.height(8.dp))
        RogHeader(
            title = "Game Library",
            subtitle = "Manage & boost your installed mobile games",
            actionIcon = {
                IconButton(
                    onClick = { viewModel.scanInstalledApps() },
                    modifier = Modifier.testTag("scan_apps_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Scan Apps",
                        tint = RogCyan
                    )
                }
            }
        )

        // Search bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { viewModel.setSearchQuery(it) },
            placeholder = { Text("Search games or apps...", color = TextMuted) },
            leadingIcon = {
                Icon(imageVector = Icons.Default.Search, contentDescription = "Search", tint = TextMuted)
            },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp)
                .testTag("library_search_input"),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = RogRed,
                unfocusedBorderColor = RogCardBorder,
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary,
                focusedContainerColor = RogCharcoal,
                unfocusedContainerColor = RogCharcoal
            ),
            shape = RoundedCornerShape(10.dp)
        )

        // Tab Row
        TabRow(
            selectedTabIndex = selectedTab.ordinal,
            containerColor = RogCharcoal,
            contentColor = RogRed,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab.ordinal]),
                    color = RogRed,
                    height = 2.dp
                )
            },
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
        ) {
            Tab(
                selected = selectedTab == LibraryTab.SAVED_GAMES,
                onClick = { viewModel.setTab(LibraryTab.SAVED_GAMES) },
                text = {
                    Text(
                        text = "SAVED (${savedGames.size})",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = if (selectedTab == LibraryTab.SAVED_GAMES) RogRed else TextSecondary
                    )
                }
            )
            Tab(
                selected = selectedTab == LibraryTab.ALL_INSTALLED,
                onClick = { viewModel.setTab(LibraryTab.ALL_INSTALLED) },
                text = {
                    Text(
                        text = "ALL APPS (${installedApps.size})",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = if (selectedTab == LibraryTab.ALL_INSTALLED) RogRed else TextSecondary
                    )
                }
            )
            Tab(
                selected = selectedTab == LibraryTab.SUGGESTED_PRESETS,
                onClick = { viewModel.setTab(LibraryTab.SUGGESTED_PRESETS) },
                text = {
                    Text(
                        text = "PRESETS (${suggestedGuides.size})",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = if (selectedTab == LibraryTab.SUGGESTED_PRESETS) RogRed else TextSecondary
                    )
                }
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (isScanning) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = RogCyan)
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(text = "Scanning device applications...", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                }
            }
        } else {
            when (selectedTab) {
                LibraryTab.SAVED_GAMES -> {
                    if (savedGames.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(32.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.Gamepad, contentDescription = null, tint = TextMuted, modifier = Modifier.size(48.dp))
                                Spacer(modifier = Modifier.height(12.dp))
                                Text(
                                    text = "Your Game Library is empty",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = TextPrimary
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Switch to 'ALL APPS' to add any installed game.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextMuted
                                )
                                Spacer(modifier = Modifier.height(16.dp))
                                RogButton(
                                    text = "Browse Installed Apps",
                                    onClick = { viewModel.setTab(LibraryTab.ALL_INSTALLED) },
                                    color = RogCyan
                                )
                            }
                        }
                    } else {
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            items(savedGames, key = { it.packageName }) { game ->
                                SavedGameCard(
                                    game = game,
                                    onLaunch = { viewModel.launchGame(game.packageName) },
                                    onToggleFavorite = { viewModel.toggleFavorite(game.packageName, game.isFavorite) },
                                    onRemove = { viewModel.removeGame(game.packageName) },
                                    onOpenGuide = { onOpenPresetGuide(game.packageName) }
                                )
                            }
                            item { Spacer(modifier = Modifier.height(16.dp)) }
                        }
                    }
                }

                LibraryTab.ALL_INSTALLED -> {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(installedApps, key = { it.packageName }) { appInfo ->
                            val isAlreadyAdded = savedGames.any { it.packageName == appInfo.packageName }
                            InstalledAppCard(
                                appInfo = appInfo,
                                isAlreadyAdded = isAlreadyAdded,
                                onAdd = { viewModel.addGame(appInfo) },
                                onRemove = { viewModel.removeGame(appInfo.packageName) },
                                onLaunch = { viewModel.launchGame(appInfo.packageName) }
                            )
                        }
                        item { Spacer(modifier = Modifier.height(16.dp)) }
                    }
                }

                LibraryTab.SUGGESTED_PRESETS -> {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(suggestedGuides, key = { it.packageName }) { guide ->
                            PresetGuideCard(
                                guide = guide,
                                onOpen = { onOpenPresetGuide(guide.packageName) }
                            )
                        }
                        item { Spacer(modifier = Modifier.height(16.dp)) }
                    }
                }
            }
        }
    }
}

@Composable
fun SavedGameCard(
    game: GameEntity,
    onLaunch: () -> Unit,
    onToggleFavorite: () -> Unit,
    onRemove: () -> Unit,
    onOpenGuide: () -> Unit
) {
    RogCard(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(RogSurface),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Gamepad, contentDescription = null, tint = RogRed)
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = game.appName,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = TextPrimary
                )
                Text(
                    text = "Mode: ${game.selectedMode} | Played: ${game.totalPlayCount}x",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }
            IconButton(onClick = onToggleFavorite) {
                Icon(
                    imageVector = if (game.isFavorite) Icons.Default.Star else Icons.Default.StarBorder,
                    contentDescription = "Favorite",
                    tint = if (game.isFavorite) Color(0xFFFFD700) else TextMuted
                )
            }
            IconButton(onClick = onOpenGuide) {
                Icon(
                    imageVector = Icons.Default.Tune,
                    contentDescription = "Presets & Optimization",
                    tint = RogCyan
                )
            }
            IconButton(onClick = onRemove) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Remove",
                    tint = TextMuted
                )
            }
            RogButton(
                text = "LAUNCH",
                onClick = onLaunch,
                color = RogRed,
                testTag = "launch_${game.packageName}"
            )
        }
    }
}

@Composable
fun InstalledAppCard(
    appInfo: InstalledAppInfo,
    isAlreadyAdded: Boolean,
    onAdd: () -> Unit,
    onRemove: () -> Unit,
    onLaunch: () -> Unit
) {
    RogCard(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(RogSurface),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Gamepad,
                    contentDescription = null,
                    tint = if (appInfo.isGame) RogRed else TextMuted
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = appInfo.appName,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = TextPrimary
                )
                Text(
                    text = if (appInfo.isGame) "Detected Game" else appInfo.packageName.take(24),
                    style = MaterialTheme.typography.bodySmall,
                    color = if (appInfo.isGame) RogCyan else TextMuted
                )
            }
            if (isAlreadyAdded) {
                RogOutlinedButton(
                    text = "ADDED",
                    onClick = onRemove,
                    color = RogGreen
                )
            } else {
                RogButton(
                    text = "+ ADD",
                    onClick = onAdd,
                    color = RogCyan
                )
            }
        }
    }
}

@Composable
fun PresetGuideCard(
    guide: com.example.data.model.GamePresetGuide,
    onOpen: () -> Unit
) {
    RogCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onOpen() }
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(RogSurface),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Gamepad, contentDescription = null, tint = RogRed)
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = guide.gameTitle,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = TextPrimary
                        )
                        Text(
                            text = "OPPO A17k / Low-RAM Recommended Setup",
                            style = MaterialTheme.typography.labelSmall,
                            color = RogCyan
                        )
                    }
                }
                Icon(Icons.Default.Tune, contentDescription = "View Guide", tint = RogCyan)
            }

            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(text = "Graphics", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    Text(text = guide.recommendedGraphics, style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold), color = TextPrimary)
                }
                Column {
                    Text(text = "Target FPS", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    Text(text = guide.recommendedFps, style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold), color = RogGreen)
                }
                Column {
                    Text(text = "Shadows", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    Text(text = guide.recommendedShadows, style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold), color = RogRed)
                }
            }
        }
    }
}
