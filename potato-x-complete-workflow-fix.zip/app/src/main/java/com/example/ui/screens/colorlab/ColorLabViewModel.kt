package com.example.ui.screens.colorlab

import android.app.Application
import android.content.Intent
import android.provider.Settings
import androidx.lifecycle.AndroidViewModel
import com.example.PotatoXApplication
import com.example.data.model.ColorProfile
import com.example.service.GamingOverlayService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class ColorLabViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as PotatoXApplication

    private val _selectedProfile = MutableStateFlow(ColorProfile.ORIGINAL)
    val selectedProfile: StateFlow<ColorProfile> = _selectedProfile.asStateFlow()

    private val _intensity = MutableStateFlow(50f)
    val intensity: StateFlow<Float> = _intensity.asStateFlow()

    private val _isOverlayActive = MutableStateFlow(false)
    val isOverlayActive: StateFlow<Boolean> = _isOverlayActive.asStateFlow()

    fun selectProfile(profile: ColorProfile) {
        _selectedProfile.value = profile
        if (_isOverlayActive.value && Settings.canDrawOverlays(app)) {
            applyOverlay()
        }
    }

    fun setIntensity(value: Float) {
        _intensity.value = value.coerceIn(10f, 100f)
        if (_isOverlayActive.value && Settings.canDrawOverlays(app)) {
            applyOverlay()
        }
    }

    fun toggleOverlay(): Boolean {
        if (!Settings.canDrawOverlays(app)) {
            return false // Caller should guide user to grant overlay permission
        }
        val newState = !_isOverlayActive.value
        _isOverlayActive.value = newState
        if (newState) {
            applyOverlay()
        } else {
            GamingOverlayService.stop(app)
        }
        return true
    }

    private fun applyOverlay() {
        val baseHex = _selectedProfile.value.colorHex
        if (baseHex == 0L) {
            GamingOverlayService.stop(app)
            return
        }
        // Scale alpha by intensity percentage
        val originalAlpha = (baseHex shr 24) and 0xFF
        val scaledAlpha = ((originalAlpha * _intensity.value) / 100f).toInt().coerceIn(10, 180)
        val rgb = baseHex and 0x00FFFFFF
        val finalHex = ((scaledAlpha.toLong() shl 24) or rgb)

        GamingOverlayService.start(app, finalHex)
    }

    fun openOverlaySettings() {
        val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION).apply {
            data = android.net.Uri.parse("package:${app.packageName}")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            app.startActivity(intent)
        } catch (ignored: Exception) {}
    }
}
