package com.example.ui.screens.colorlab

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BrightnessMedium
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.ColorProfile
import com.example.ui.components.RogButton
import com.example.ui.components.RogCard
import com.example.ui.components.RogHeader
import com.example.ui.components.RogOutlinedButton
import com.example.ui.theme.RogBlack
import com.example.ui.theme.RogCardBorder
import com.example.ui.theme.RogCardBorderActive
import com.example.ui.theme.RogCharcoal
import com.example.ui.theme.RogCyan
import com.example.ui.theme.RogGreen
import com.example.ui.theme.RogPurple
import com.example.ui.theme.RogRed
import com.example.ui.theme.RogSurface
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun ColorLabScreen(
    viewModel: ColorLabViewModel = viewModel()
) {
    val context = LocalContext.current
    val selectedProfile by viewModel.selectedProfile.collectAsState()
    val intensity by viewModel.intensity.collectAsState()
    val isOverlayActive by viewModel.isOverlayActive.collectAsState()

    var showPermissionHint by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(RogBlack)
            .padding(horizontal = 16.dp)
            .testTag("color_lab_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            RogHeader(
                title = "Color Lab",
                subtitle = "Custom gaming visual profiles & night filters",
                actionIcon = {
                    IconButtonIcon(
                        onClick = { viewModel.selectProfile(ColorProfile.ORIGINAL) }
                    )
                }
            )
        }

        // Live Simulated In-Game Preview Box
        item {
            RogCard(
                modifier = Modifier.fillMaxWidth(),
                borderColor = RogCyan.copy(alpha = 0.5f)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "LIVE VISUAL SIMULATION",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Black),
                        color = RogCyan
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    // Mock Game Canvas Preview
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF1E2235))
                    ) {
                        // Background game mock art
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(12.dp),
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("FPS: 60 (Simulated)", style = MaterialTheme.typography.labelSmall, color = RogGreen)
                                Text("MAP: CYBER RUINS", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Text(
                                    text = "TARGET ACQUIRED",
                                    style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Black),
                                    color = TextPrimary
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("HEALTH: 100%", style = MaterialTheme.typography.labelSmall, color = RogCyan)
                                Text("AMMO: 30 / 120", style = MaterialTheme.typography.labelSmall, color = TextPrimary)
                            }
                        }

                        // Selected Color Tint Layer on preview
                        if (selectedProfile.colorHex != 0L) {
                            val alpha = ((selectedProfile.colorHex shr 24) and 0xFF) * (intensity / 100f)
                            val colorWithAlpha = Color(
                                (selectedProfile.colorHex and 0x00FFFFFF) or (alpha.toLong() shl 24)
                            )
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(colorWithAlpha)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Active Profile: ${selectedProfile.title} (${intensity.toInt()}% Intensity)",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }
        }

        // Honest Disclaimer Card (MANDATORY REQUIREMENT)
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF191A24))
                    .border(1.dp, RogCardBorder, RoundedCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                Row(verticalAlignment = Alignment.Top) {
                    Icon(Icons.Default.Info, contentDescription = null, tint = RogCyan, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Color Lab operates via an optional non-intrusive Android screen overlay or display tone shortcut. It does not and cannot modify actual game 3D engine textures or internal rendering pipelines.",
                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                        color = TextSecondary
                    )
                }
            }
        }

        // Color Profiles Grid / Row
        item {
            RogHeader(
                title = "Preset Profiles",
                subtitle = "Choose your gaming optical enhancement"
            )

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                ColorProfile.values().forEach { profile ->
                    val isSelected = profile == selectedProfile
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isSelected) RogSurface else RogCharcoal)
                            .border(
                                width = if (isSelected) 1.5.dp else 1.dp,
                                color = if (isSelected) RogRed else RogCardBorder,
                                shape = RoundedCornerShape(10.dp)
                            )
                            .clickable { viewModel.selectProfile(profile) }
                            .padding(12.dp)
                            .testTag("color_profile_${profile.name.lowercase()}")
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(24.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(
                                        if (profile.colorHex == 0L) Color.Gray
                                        else Color(profile.colorHex or 0xFF000000)
                                    )
                                    .border(1.dp, Color.White.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = profile.title,
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    color = if (isSelected) TextPrimary else TextSecondary
                                )
                                Text(
                                    text = profile.description,
                                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                    color = TextMuted
                                )
                            }
                            if (isSelected) {
                                Icon(Icons.Default.Check, contentDescription = "Selected", tint = RogRed)
                            }
                        }
                    }
                }
            }
        }

        // Intensity Slider
        item {
            RogCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Filter Intensity",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = TextPrimary
                        )
                        Text(
                            text = "${intensity.toInt()}%",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black),
                            color = RogCyan
                        )
                    }
                    Slider(
                        value = intensity,
                        onValueChange = { viewModel.setIntensity(it) },
                        valueRange = 10f..100f,
                        colors = SliderDefaults.colors(
                            thumbColor = RogRed,
                            activeTrackColor = RogRed,
                            inactiveTrackColor = RogSurface
                        )
                    )
                }
            }
        }

        // System Display Brightness & System Overlay controls
        item {
            RogCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "Apply Filter Across Games",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = TextPrimary
                            )
                            Text(
                                text = "Uses optional system display overlay",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                        Switch(
                            checked = isOverlayActive,
                            onCheckedChange = {
                                val success = viewModel.toggleOverlay()
                                if (!success) {
                                    showPermissionHint = true
                                    viewModel.openOverlaySettings()
                                }
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = RogRed,
                                uncheckedThumbColor = TextMuted,
                                uncheckedTrackColor = RogSurface
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    RogOutlinedButton(
                        text = "Open System Display & Brightness Settings",
                        onClick = {
                            val intent = Intent(Settings.ACTION_DISPLAY_SETTINGS).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            context.startActivity(intent)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        color = RogCyan
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
fun IconButtonIcon(onClick: () -> Unit) {
    androidx.compose.material3.IconButton(onClick = onClick) {
        Icon(Icons.Default.RestartAlt, contentDescription = "Reset Color", tint = RogCyan)
    }
}
