package com.example.ui.screens.refreshrate

import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.view.WindowManager
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.RogButton
import com.example.ui.components.RogCard
import com.example.ui.components.RogHeader
import com.example.ui.theme.RogBlack
import com.example.ui.theme.RogCardBorder
import com.example.ui.theme.RogCharcoal
import com.example.ui.theme.RogCyan
import com.example.ui.theme.RogGreen
import com.example.ui.theme.RogRed
import com.example.ui.theme.RogSurface
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun RefreshRateScreen() {
    val context = LocalContext.current

    val windowManager = remember {
        context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
    }

    val display = remember {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                context.display
            } catch (e: Exception) {
                @Suppress("DEPRECATION")
                windowManager?.defaultDisplay
            }
        } else {
            @Suppress("DEPRECATION")
            windowManager?.defaultDisplay
        }
    }

    val currentRate = remember { display?.mode?.refreshRate ?: 60f }
    val supportedRates = remember {
        display?.supportedModes?.map { it.refreshRate }?.distinct()?.sorted() ?: listOf(60f)
    }

    val maxHardwareRate = supportedRates.maxOrNull() ?: 60f
    val isLockedAt60 = maxHardwareRate <= 60.5f

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(RogBlack)
            .padding(horizontal = 16.dp)
            .testTag("refresh_rate_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            RogHeader(
                title = "Refresh Rate",
                subtitle = "Hardware display capability detection"
            )
        }

        // Active Refresh Rate Badge
        item {
            RogCard(
                modifier = Modifier.fillMaxWidth(),
                borderColor = RogCyan.copy(alpha = 0.6f)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "CURRENT HARDWARE REFRESH RATE",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = RogCyan
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "${currentRate.toInt()} Hz",
                        style = MaterialTheme.typography.headlineLarge.copy(
                            fontWeight = FontWeight.Black,
                            fontSize = 44.sp
                        ),
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Active Display Mode: ${display?.mode?.physicalWidth ?: 720} x ${display?.mode?.physicalHeight ?: 1600} @ ${currentRate.toInt()}Hz",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }
        }

        // Hardware Limitation & Honesty Notice (MANDATORY REQUIREMENT)
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF181A25))
                    .border(1.dp, RogCardBorder, RoundedCornerShape(8.dp))
                    .padding(14.dp)
            ) {
                Row(verticalAlignment = Alignment.Top) {
                    Icon(Icons.Default.Info, contentDescription = null, tint = RogCyan, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = if (isLockedAt60) "HARDWARE CAP: 60 HZ MAXIMUM" else "VARIABLE REFRESH DETECTED",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                            color = if (isLockedAt60) RogCyan else RogGreen
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (isLockedAt60) {
                                "This device (such as OPPO A17k with IPS LCD display) physically supports a maximum refresh rate of 60 Hz. Potato X never makes false claims of unlocking 90 Hz or 120 Hz on displays without underlying panel hardware support."
                            } else {
                                "Your display hardware supports switching refresh modes. You can configure dynamic or high refresh rates via system display settings."
                            },
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp),
                            color = TextSecondary
                        )
                    }
                }
            }
        }

        // Supported Display Modes List
        item {
            RogHeader(
                title = "Hardware Modes Detected",
                subtitle = "Modes exposed by display driver"
            )

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                supportedRates.forEach { rate ->
                    val isCurrent = (rate - currentRate).let { if (it < 0) -it else it } < 0.5f
                    RogCard(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Speed, contentDescription = null, tint = if (isCurrent) RogRed else TextMuted)
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = "${rate.toInt()} Hz Mode",
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                        color = TextPrimary
                                    )
                                    Text(
                                        text = if (isCurrent) "Currently Active on Display" else "Supported Alternative Mode",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = if (isCurrent) RogGreen else TextMuted
                                    )
                                }
                            }
                            if (isCurrent) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(RogGreen.copy(alpha = 0.2f))
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text("ACTIVE", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Black), color = RogGreen)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Shortcut to Android Display Settings
        item {
            RogButton(
                text = "OPEN SYSTEM DISPLAY SETTINGS",
                onClick = {
                    val intent = Intent(Settings.ACTION_DISPLAY_SETTINGS).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    try {
                        context.startActivity(intent)
                    } catch (ignored: Exception) {}
                },
                modifier = Modifier.fillMaxWidth(),
                color = RogCyan,
                testTag = "open_display_settings_button"
            )
        }

        item {
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
