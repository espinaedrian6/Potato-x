package com.example.ui.screens.installation

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryAlert
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Help
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.QueryStats
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.RogButton
import com.example.ui.components.RogCard
import com.example.ui.components.RogHeader
import com.example.ui.components.RogOutlinedButton
import com.example.ui.theme.RogBlack
import com.example.ui.theme.RogCardBorder
import com.example.ui.theme.RogCharcoal
import com.example.ui.theme.RogCyan
import com.example.ui.theme.RogGreen
import com.example.ui.theme.RogRed
import com.example.ui.theme.RogSurface
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun InstallationScreen() {
    val context = LocalContext.current

    val hasOverlay = remember(context) { Settings.canDrawOverlays(context) }
    val powerManager = remember(context) { context.getSystemService(Context.POWER_SERVICE) as? PowerManager }
    val isBatteryExempt = remember(context, powerManager) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            powerManager?.isIgnoringBatteryOptimizations(context.packageName) == true
        } else true
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(RogBlack)
            .padding(horizontal = 16.dp)
            .testTag("installation_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            RogHeader(
                title = "Permissions & Modules",
                subtitle = "Configure system access safely and transparently"
            )
        }

        // OPPO A17k / Android 12 Compatibility Checker Card
        item {
            RogCard(
                modifier = Modifier.fillMaxWidth(),
                borderColor = RogGreen.copy(alpha = 0.5f)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = RogGreen, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "COMPATIBILITY VERIFIED",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black),
                            color = RogGreen
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Device: ${Build.MANUFACTURER.uppercase()} ${Build.MODEL} (Android ${Build.VERSION.RELEASE}, API ${Build.VERSION.SDK_INT})",
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "POTATO X is fully tailored for low-overhead operation on Helio G35 / 3GB RAM devices like OPPO A17k with zero background memory bloat.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }
        }

        // Permission Items List
        item {
            RogHeader(
                title = "System Permissions Setup",
                subtitle = "Granted only when authorized by you"
            )

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // Floating Overlay
                PermissionCard(
                    title = "Floating Gaming HUD Overlay",
                    description = "Allows the mini performance widget and Color Lab filter to display while gaming.",
                    isGranted = hasOverlay,
                    onConfigure = {
                        val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION).apply {
                            data = Uri.parse("package:${context.packageName}")
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        try { context.startActivity(intent) } catch (ignored: Exception) {}
                    }
                )

                // Battery Optimization
                PermissionCard(
                    title = "Battery Optimization Exemption",
                    description = "Prevents aggressive background killing of Potato X telemetry during long gaming matches.",
                    isGranted = isBatteryExempt,
                    onConfigure = {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            val intent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            try { context.startActivity(intent) } catch (ignored: Exception) {}
                        }
                    }
                )

                // Usage Access
                PermissionCard(
                    title = "Usage Access (Optional)",
                    description = "Allows automatic loading of your custom profile whenever a game starts.",
                    isGranted = false,
                    onConfigure = {
                        val intent = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        try { context.startActivity(intent) } catch (ignored: Exception) {}
                    }
                )

                // Notification Access
                PermissionCard(
                    title = "Gaming Session Notifications",
                    description = "Keeps session duration and HUD controls accessible from the notification shade.",
                    isGranted = true,
                    onConfigure = {
                        val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                            putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        try { context.startActivity(intent) } catch (ignored: Exception) {}
                    }
                )
            }
        }

        // Troubleshooting & FAQ
        item {
            RogHeader(
                title = "Troubleshooting",
                subtitle = "Answers to common low-end phone questions"
            )

            RogCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp)) {
                    FaqItem(
                        question = "Why does my phone only show 60 Hz?",
                        answer = "The OPPO A17k hardware display is physically built with a 60 Hz LCD panel. Any app claiming to unlock 90 Hz or 120 Hz on a 60 Hz screen is fabricating data or displaying a fake counter."
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    FaqItem(
                        question = "Does Potato X require root or Shizuku?",
                        answer = "No. Potato X is completely standalone. Every core feature—memory trimming, game library, telemetry, HUD, and presets—runs seamlessly using standard Android APIs."
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    FaqItem(
                        question = "How does Potato Mode improve smoothness?",
                        answer = "Potato Mode suspends animated gauges, trims cached memory buffers, and instructs the operating system to schedule all CPU cores for the foreground game."
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
fun PermissionCard(
    title: String,
    description: String,
    isGranted: Boolean,
    onConfigure: () -> Unit
) {
    RogCard(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (isGranted) RogGreen.copy(alpha = 0.2f) else RogSurface),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isGranted) Icons.Default.Check else Icons.Default.Close,
                    contentDescription = null,
                    tint = if (isGranted) RogGreen else TextMuted
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = TextPrimary
                )
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            if (isGranted) {
                RogOutlinedButton(
                    text = "ACTIVE",
                    onClick = onConfigure,
                    color = RogGreen
                )
            } else {
                RogButton(
                    text = "SETUP",
                    onClick = onConfigure,
                    color = RogCyan
                )
            }
        }
    }
}

@Composable
fun FaqItem(question: String, answer: String) {
    Column {
        Text(
            text = question,
            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
            color = RogCyan
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = answer,
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary
        )
    }
}
