package com.example.ui.screens.booster

import android.content.Intent
import android.provider.Settings
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BrightnessMedium
import androidx.compose.material.icons.filled.DoNotDisturb
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.GamingMode
import com.example.ui.components.RogButton
import com.example.ui.components.RogCard
import com.example.ui.components.RogCircularGauge
import com.example.ui.components.RogHeader
import com.example.ui.components.RogOutlinedButton
import com.example.ui.theme.RogBlack
import com.example.ui.theme.RogCardBorder
import com.example.ui.theme.RogCardBorderActive
import com.example.ui.theme.RogCharcoal
import com.example.ui.theme.RogCyan
import com.example.ui.theme.RogGreen
import com.example.ui.theme.RogPurple
import com.example.ui.theme.RogRed
import com.example.ui.theme.RogSurface
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale

@Composable
fun BoosterScreen(
    viewModel: BoosterViewModel = viewModel()
) {
    val context = LocalContext.current
    val stats by viewModel.deviceStats.collectAsState()
    val selectedMode by viewModel.selectedMode.collectAsState()
    val pingMs by viewModel.networkPingMs.collectAsState()
    val isTestingPing by viewModel.isTestingPing.collectAsState()
    val isSessionActive by viewModel.isSessionActive.collectAsState()
    val isOverlayActive by viewModel.isOverlayActive.collectAsState()
    val elapsedSecs by viewModel.sessionElapsedSeconds.collectAsState()

    var overlayErrorNotice by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(RogBlack)
            .padding(horizontal = 16.dp)
            .testTag("booster_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            RogHeader(
                title = "Game Booster Control",
                subtitle = "Active real-time gaming tuning & telemetry"
            )
        }

        // Session Timer Card
        item {
            RogCard(
                modifier = Modifier.fillMaxWidth(),
                borderColor = if (isSessionActive) RogRed else RogCardBorder
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Timer, contentDescription = null, tint = RogCyan)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "GAMING SESSION",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                color = RogCyan
                            )
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (isSessionActive) RogRed.copy(alpha = 0.2f) else RogSurface)
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = if (isSessionActive) "RECORDING" else "IDLE",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = if (isSessionActive) RogRed else TextMuted
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = viewModel.getFormattedSessionTime(),
                        style = MaterialTheme.typography.headlineLarge.copy(
                            fontWeight = FontWeight.Black,
                            letterSpacing = 2.sp,
                            fontSize = 38.sp
                        ),
                        color = TextPrimary
                    )

                    Spacer(modifier = Modifier.height(14.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center
                    ) {
                        if (!isSessionActive) {
                            RogButton(
                                text = "Start Session",
                                onClick = { viewModel.startSession() },
                                color = RogRed
                            )
                        } else {
                            RogButton(
                                text = "Pause",
                                onClick = { viewModel.pauseSession() },
                                color = RogPurple
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        RogOutlinedButton(
                            text = "Reset",
                            onClick = { viewModel.resetSession() },
                            color = TextSecondary
                        )
                    }
                }
            }
        }

        // Live Telemetry: RAM, Temp, Network Ping
        item {
            RogCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "LIVE PERFORMANCE METRICS",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Black),
                        color = RogCyan
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        RogCircularGauge(
                            percentage = stats.ramUsagePercent,
                            label = "RAM",
                            subLabel = "${stats.usedRamMb}MB Used",
                            color = if (stats.ramUsagePercent > 80) RogRed else RogCyan,
                            size = 110.dp
                        )

                        val tempStr = stats.batteryTempCelsius?.let {
                            "${String.format(Locale.US, "%.1f", it)}°C"
                        } ?: "--"
                        RogCircularGauge(
                            percentage = stats.batteryLevel,
                            label = "TEMP",
                            subLabel = tempStr,
                            color = if (stats.batteryLevel < 25) RogRed else RogGreen,
                            size = 110.dp
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Network Ping Box
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(RogSurface)
                            .padding(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.NetworkCheck, contentDescription = null, tint = RogCyan)
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(text = "Network Latency", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                                    Text(
                                        text = if (isTestingPing) "Measuring..." else if (pingMs != null) "$pingMs ms" else "Offline / Disconnected",
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                        color = if (pingMs != null && pingMs!! < 60) RogGreen else if (pingMs != null && pingMs!! < 120) Color(0xFFFFD700) else RogRed
                                    )
                                }
                            }
                            IconButton(onClick = { viewModel.testNetworkPing() }) {
                                if (isTestingPing) {
                                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = RogCyan)
                                } else {
                                    Icon(Icons.Default.Refresh, contentDescription = "Test Ping", tint = RogCyan)
                                }
                            }
                        }
                    }
                }
            }
        }

        // FPS Notice Card (MANDATORY HONESTY REQUIREMENT)
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF1B1D28))
                    .border(1.dp, Color(0xFF2E334D), RoundedCornerShape(8.dp))
                    .padding(14.dp)
            ) {
                Row(verticalAlignment = Alignment.Top) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "FPS Disclaimer",
                        tint = RogCyan,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "FPS METRIC TRANSPARENCY",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = RogCyan
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "FPS unavailable — Android does not expose this measurement to this app without root or specialized game vendor APIs. Potato X never displays fabricated or simulated FPS numbers.",
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                            color = TextSecondary
                        )
                    }
                }
            }
        }

        // Quick Settings & Shortcuts
        item {
            RogHeader(
                title = "Gaming Tools",
                subtitle = "Convenience shortcuts for low-distraction gaming"
            )

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                // Floating HUD Overlay Toggle
                RogCard(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Widgets, contentDescription = null, tint = RogRed)
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "Floating Gaming HUD",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    color = TextPrimary
                                )
                                Text(
                                    text = "Draggable in-game overlay with timer & RAM gauge",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )
                            }
                        }
                        Switch(
                            checked = isOverlayActive,
                            onCheckedChange = {
                                val success = viewModel.toggleOverlay()
                                if (!success) {
                                    overlayErrorNotice = true
                                    viewModel.openOverlaySettings()
                                }
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = RogRed,
                                uncheckedThumbColor = TextMuted,
                                uncheckedTrackColor = RogSurface
                            )
                        )
                    }
                }

                // DND Shortcut
                RogCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.openDndSettings() }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.DoNotDisturb, contentDescription = null, tint = RogPurple)
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "Gaming Do Not Disturb",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    color = TextPrimary
                                )
                                Text(
                                    text = "Silence calls and banners during ranked games",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )
                            }
                        }
                        Icon(Icons.Default.Speed, contentDescription = "Open", tint = TextMuted)
                    }
                }

                // Screen Brightness Shortcut
                RogCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            val intent = Intent(Settings.ACTION_DISPLAY_SETTINGS).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            context.startActivity(intent)
                        }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.BrightnessMedium, contentDescription = null, tint = RogCyan)
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "Display Brightness & Refresh",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    color = TextPrimary
                                )
                                Text(
                                    text = "Open system display settings",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )
                            }
                        }
                        Icon(Icons.Default.Speed, contentDescription = "Open", tint = TextMuted)
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
