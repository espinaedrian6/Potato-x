package com.example.ui.navigation

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoMode
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.PotatoXApplication
import com.example.ui.components.RogCard
import com.example.ui.components.RogHeader
import com.example.ui.screens.booster.BoosterScreen
import com.example.ui.screens.colorlab.ColorLabScreen
import com.example.ui.screens.dashboard.DashboardScreen
import com.example.ui.screens.installation.InstallationScreen
import com.example.ui.screens.library.GameLibraryScreen
import com.example.ui.screens.potatographics.PotatoGraphicsScreen
import com.example.ui.screens.refreshrate.RefreshRateScreen
import com.example.ui.screens.settings.SettingsScreen
import com.example.ui.screens.shizuku.ShizukuScreen
import com.example.ui.theme.RogBlack
import com.example.ui.theme.RogCardBorder
import com.example.ui.theme.RogCharcoal
import com.example.ui.theme.RogCyan
import com.example.ui.theme.RogPurple
import com.example.ui.theme.RogRed
import com.example.ui.theme.RogSurface
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

enum class NavDestination(val label: String, val icon: ImageVector) {
    DASHBOARD("Control", Icons.Default.Dashboard),
    LIBRARY("Games", Icons.Default.Gamepad),
    BOOSTER("Booster", Icons.Default.Bolt),
    COLOR_LAB("Color Lab", Icons.Default.Palette),
    MORE("More", Icons.Default.MoreHoriz),

    // Sub-screens
    REFRESH_RATE("Refresh Rate", Icons.Default.Speed),
    POTATO_GRAPHICS("Graphics Presets", Icons.Default.Tune),
    SHIZUKU("Shizuku ADB", Icons.Default.AutoMode),
    PERMISSIONS("Permissions", Icons.Default.Security),
    SETTINGS("Settings", Icons.Default.Settings)
}

@Composable
fun MainScreen() {
    var currentDestination by remember { mutableStateOf(NavDestination.DASHBOARD) }
    var backStack by remember { mutableStateOf(listOf(NavDestination.DASHBOARD)) }

    val context = LocalContext.current
    val app = context.applicationContext as PotatoXApplication
    val gameRepo = app.gameRepository

    fun navigateTo(dest: NavDestination) {
        if (dest != currentDestination) {
            backStack = backStack + dest
            currentDestination = dest
        }
    }

    fun navigateBack(): Boolean {
        if (backStack.size > 1) {
            val updated = backStack.dropLast(1)
            backStack = updated
            currentDestination = updated.last()
            return true
        } else if (currentDestination != NavDestination.DASHBOARD) {
            currentDestination = NavDestination.DASHBOARD
            backStack = listOf(NavDestination.DASHBOARD)
            return true
        }
        return false
    }

    // Android System Back Button Handler
    BackHandler(enabled = currentDestination != NavDestination.DASHBOARD) {
        navigateBack()
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(RogBlack),
        bottomBar = {
            val primaryTabs = listOf(
                NavDestination.DASHBOARD,
                NavDestination.LIBRARY,
                NavDestination.BOOSTER,
                NavDestination.COLOR_LAB,
                NavDestination.MORE
            )
            val isPrimarySelected = primaryTabs.contains(currentDestination)
            val selectedNav = if (isPrimarySelected) currentDestination else NavDestination.MORE

            NavigationBar(
                modifier = Modifier
                    .navigationBarsPadding()
                    .border(1.dp, RogCardBorder, RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp)),
                containerColor = RogCharcoal,
                contentColor = RogRed
            ) {
                primaryTabs.forEach { tab ->
                    val isSelected = tab == selectedNav
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { navigateTo(tab) },
                        icon = {
                            Icon(
                                imageVector = tab.icon,
                                contentDescription = tab.label,
                                tint = if (isSelected) RogRed else TextMuted
                            )
                        },
                        label = {
                            Text(
                                text = tab.label,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = if (isSelected) FontWeight.Black else FontWeight.Normal
                                ),
                                color = if (isSelected) RogRed else TextMuted
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = RogRed.copy(alpha = 0.15f),
                            selectedIconColor = RogRed,
                            unselectedIconColor = TextMuted
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .statusBarsPadding()
        ) {
            AnimatedContent(
                targetState = currentDestination,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "nav_transition"
            ) { destination ->
                when (destination) {
                    NavDestination.DASHBOARD -> DashboardScreen(
                        onNavigateToLibrary = { navigateTo(NavDestination.LIBRARY) },
                        onNavigateToBooster = { navigateTo(NavDestination.BOOSTER) },
                        onLaunchGame = { pkg ->
                            val intent = context.packageManager.getLaunchIntentForPackage(pkg)
                            if (intent != null) {
                                intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                                context.startActivity(intent)
                            }
                        }
                    )

                    NavDestination.LIBRARY -> GameLibraryScreen(
                        onOpenPresetGuide = { _ ->
                            navigateTo(NavDestination.POTATO_GRAPHICS)
                        }
                    )

                    NavDestination.BOOSTER -> BoosterScreen()

                    NavDestination.COLOR_LAB -> ColorLabScreen()

                    NavDestination.MORE -> MoreMenuScreen(
                        onNavigate = { dest -> navigateTo(dest) }
                    )

                    NavDestination.REFRESH_RATE -> RefreshRateScreen()

                    NavDestination.POTATO_GRAPHICS -> PotatoGraphicsScreen(
                        guides = gameRepo.suggestedPresetGuides,
                        onLaunchGame = { pkg ->
                            val intent = context.packageManager.getLaunchIntentForPackage(pkg)
                            if (intent != null) {
                                intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                                context.startActivity(intent)
                            }
                        }
                    )

                    NavDestination.SHIZUKU -> ShizukuScreen()

                    NavDestination.PERMISSIONS -> InstallationScreen()

                    NavDestination.SETTINGS -> SettingsScreen(
                        onNavigateToPermissions = { navigateTo(NavDestination.PERMISSIONS) },
                        onNavigateToShizuku = { navigateTo(NavDestination.SHIZUKU) }
                    )
                }
            }
        }
    }
}

@Composable
fun MoreMenuScreen(
    onNavigate: (NavDestination) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(RogBlack)
            .padding(horizontal = 16.dp)
            .testTag("more_menu_screen"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            RogHeader(
                title = "ARMOURY CRATE MODULES",
                subtitle = "Advanced performance tools & system integrations"
            )
        }

        item {
            MoreMenuItem(
                title = "Hardware Refresh Rate",
                subtitle = "Detect display driver refresh modes & 60Hz limit",
                icon = Icons.Default.Speed,
                color = RogCyan,
                onClick = { onNavigate(NavDestination.REFRESH_RATE) }
            )
        }

        item {
            MoreMenuItem(
                title = "Potato Graphics System",
                subtitle = "MLBB, CoD Mobile, Roblox & PUBG stability guides",
                icon = Icons.Default.Tune,
                color = RogRed,
                onClick = { onNavigate(NavDestination.POTATO_GRAPHICS) }
            )
        }

        item {
            MoreMenuItem(
                title = "Shizuku ADB Diagnostics",
                subtitle = "Optional elevated low-level memory inspection",
                icon = Icons.Default.AutoMode,
                color = RogPurple,
                onClick = { onNavigate(NavDestination.SHIZUKU) }
            )
        }

        item {
            MoreMenuItem(
                title = "Permissions & Compatibility",
                subtitle = "Floating HUD setup, battery ignore & OPPO A17k check",
                icon = Icons.Default.Security,
                color = RogCyan,
                onClick = { onNavigate(NavDestination.PERMISSIONS) }
            )
        }

        item {
            MoreMenuItem(
                title = "Settings & Privacy",
                subtitle = "Animations, cache cleaner, 100% offline guarantee",
                icon = Icons.Default.Settings,
                color = TextSecondary,
                onClick = { onNavigate(NavDestination.SETTINGS) }
            )
        }

        item {
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
fun MoreMenuItem(
    title: String,
    subtitle: String,
    icon: ImageVector,
    color: Color,
    onClick: () -> Unit
) {
    RogCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(color.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = color)
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = TextPrimary
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }
            Text(">", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = color)
        }
    }
}
