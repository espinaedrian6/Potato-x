package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val RogDarkColorScheme = darkColorScheme(
    primary = RogRed,
    onPrimary = Color.White,
    primaryContainer = RogRedDark,
    onPrimaryContainer = Color.White,
    secondary = RogCyan,
    onSecondary = Color.Black,
    secondaryContainer = Color(0xFF004953),
    onSecondaryContainer = RogCyan,
    tertiary = RogPurple,
    onTertiary = Color.White,
    background = RogBlack,
    onBackground = TextPrimary,
    surface = RogCharcoal,
    onSurface = TextPrimary,
    surfaceVariant = RogSurface,
    onSurfaceVariant = TextSecondary,
    outline = RogCardBorder,
    outlineVariant = RogSurfaceVariant,
    error = RogRed,
    onError = Color.White
)

@Composable
fun PotatoXTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = RogDarkColorScheme,
        typography = Typography,
        content = content
    )
}

// Backwards-compatible alias if needed
@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    PotatoXTheme(content = content)
}
