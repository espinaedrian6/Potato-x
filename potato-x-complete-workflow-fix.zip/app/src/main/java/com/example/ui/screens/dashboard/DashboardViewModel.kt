package com.example.ui.screens.dashboard

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.PotatoXApplication
import com.example.data.model.DeviceStats
import com.example.data.model.GameEntity
import com.example.data.model.GamingMode
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class OptimizationResult(
    val freedCacheMb: Long = 0L,
    val trimmedProcesses: Int = 0,
    val timestamp: Long = 0L,
    val message: String = ""
)

class DashboardViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as PotatoXApplication
    private val statsRepo = app.systemStatsRepository
    private val gameRepo = app.gameRepository

    private val _deviceStats = MutableStateFlow(statsRepo.getRealDeviceStats())
    val deviceStats: StateFlow<DeviceStats> = _deviceStats.asStateFlow()

    private val _selectedMode = MutableStateFlow(GamingMode.BALANCED)
    val selectedMode: StateFlow<GamingMode> = _selectedMode.asStateFlow()

    private val _optimizationResult = MutableStateFlow<OptimizationResult?>(null)
    val optimizationResult: StateFlow<OptimizationResult?> = _optimizationResult.asStateFlow()

    private val _isOptimizing = MutableStateFlow(false)
    val isOptimizing: StateFlow<Boolean> = _isOptimizing.asStateFlow()

    val recentGames: StateFlow<List<GameEntity>> = gameRepo.recentGames.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val allGames: StateFlow<List<GameEntity>> = gameRepo.allGames.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    private var pollingJob: Job? = null

    init {
        startStatsPolling()
    }

    fun startStatsPolling() {
        pollingJob?.cancel()
        pollingJob = viewModelScope.launch {
            while (isActive) {
                try {
                    _deviceStats.value = statsRepo.getRealDeviceStats()
                } catch (ignored: Exception) {}
                delay(2000L)
            }
        }
    }

    fun stopStatsPolling() {
        pollingJob?.cancel()
    }

    fun setGamingMode(mode: GamingMode) {
        _selectedMode.value = mode
    }

    fun runQuickOptimization() {
        if (_isOptimizing.value) return
        viewModelScope.launch {
            _isOptimizing.value = true
            val freedMb = statsRepo.clearPotatoXCache()
            val trimmedCount = statsRepo.optimizeBackgroundProcesses()
            _deviceStats.value = statsRepo.getRealDeviceStats()
            _optimizationResult.value = OptimizationResult(
                freedCacheMb = freedMb,
                trimmedProcesses = trimmedCount,
                timestamp = System.currentTimeMillis(),
                message = "Cleaned ${freedMb}MB temporary cache & trimmed $trimmedCount background tasks."
            )
            _isOptimizing.value = false
        }
    }

    fun clearOptimizationMessage() {
        _optimizationResult.value = null
    }

    override fun onCleared() {
        super.onCleared()
        stopStatsPolling()
    }
}
