package com.example.ui.screens.library

import android.app.Application
import android.content.Intent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.PotatoXApplication
import com.example.data.model.GameEntity
import com.example.data.model.InstalledAppInfo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class LibraryTab {
    SAVED_GAMES,
    ALL_INSTALLED,
    SUGGESTED_PRESETS
}

class LibraryViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as PotatoXApplication
    private val gameRepo = app.gameRepository

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedTab = MutableStateFlow(LibraryTab.SAVED_GAMES)
    val selectedTab: StateFlow<LibraryTab> = _selectedTab.asStateFlow()

    private val _installedApps = MutableStateFlow<List<InstalledAppInfo>>(emptyList())
    val installedApps: StateFlow<List<InstalledAppInfo>> = _installedApps.asStateFlow()

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    val savedGames: StateFlow<List<GameEntity>> = gameRepo.allGames.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val suggestedGuides = gameRepo.suggestedPresetGuides

    val filteredSavedGames: StateFlow<List<GameEntity>> = combine(savedGames, searchQuery) { games, query ->
        if (query.isBlank()) games
        else games.filter { it.appName.contains(query, ignoreCase = true) || it.packageName.contains(query, ignoreCase = true) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val filteredInstalledApps: StateFlow<List<InstalledAppInfo>> = combine(installedApps, searchQuery) { apps, query ->
        if (query.isBlank()) apps
        else apps.filter { it.appName.contains(query, ignoreCase = true) || it.packageName.contains(query, ignoreCase = true) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        scanInstalledApps()
    }

    fun setTab(tab: LibraryTab) {
        _selectedTab.value = tab
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun scanInstalledApps() {
        viewModelScope.launch {
            _isScanning.value = true
            _installedApps.value = gameRepo.getInstalledLaunchableApps()
            _isScanning.value = false
        }
    }

    fun addGame(appInfo: InstalledAppInfo) {
        viewModelScope.launch {
            gameRepo.addGameToLibrary(appInfo.packageName, appInfo.appName, isSuggested = false)
        }
    }

    fun removeGame(packageName: String) {
        viewModelScope.launch {
            gameRepo.removeGameFromLibrary(packageName)
        }
    }

    fun toggleFavorite(packageName: String, currentStatus: Boolean) {
        viewModelScope.launch {
            gameRepo.toggleFavorite(packageName, !currentStatus)
        }
    }

    fun launchGame(packageName: String): Boolean {
        val pm = app.packageManager
        val launchIntent = pm.getLaunchIntentForPackage(packageName) ?: return false
        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            app.startActivity(launchIntent)
            viewModelScope.launch {
                gameRepo.recordGameLaunch(packageName)
            }
            true
        } catch (e: Exception) {
            false
        }
    }
}
