package com.example.ui.screens.dashboard

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.GamingMode
import com.example.ui.components.RogButton
import com.example.ui.components.RogCard
import com.example.ui.components.RogCircularGauge
import com.example.ui.components.RogHeader
import com.example.ui.components.RogLinearProgressBar
import com.example.ui.theme.RogBlack
import com.example.ui.theme.RogCardBorder
import com.example.ui.theme.RogCardBorderActive
import com.example.ui.theme.RogCharcoal
import com.example.ui.theme.RogCyan
import com.example.ui.theme.RogGreen
import com.example.ui.theme.RogPurple
import com.example.ui.theme.RogRed
import com.example.ui.theme.RogRedGlow
import com.example.ui.theme.RogSurface
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale

@Composable
fun DashboardScreen(
    viewModel: DashboardViewModel = viewModel(),
    onNavigateToLibrary: () -> Unit,
    onNavigateToBooster: () -> Unit,
    onLaunchGame: (String) -> Unit
) {
    val stats by viewModel.deviceStats.collectAsState()
    val selectedMode by viewModel.selectedMode.collectAsState()
    val recentGames by viewModel.recentGames.collectAsState()
    val allGames by viewModel.allGames.collectAsState()
    val isOptimizing by viewModel.isOptimizing.collectAsState()
    val optResult by viewModel.optimizationResult.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(RogBlack)
            .padding(horizontal = 16.dp)
            .testTag("dashboard_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            // ROG Brand Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "POTATO",
                            style = MaterialTheme.typography.headlineLarge.copy(
                                fontWeight = FontWeight.Black,
                                letterSpacing = 2.sp
                            ),
                            color = TextPrimary
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "X",
                            style = MaterialTheme.typography.headlineLarge.copy(
                                fontWeight = FontWeight.Black,
                                letterSpacing = 2.sp
                            ),
                            color = RogRed
                        )
                    }
                    Text(
                        text = "ROG GAMING CONTROL CENTER",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        ),
                        color = RogCyan
                    )
                }

                // Device Model Chip
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(RogSurface)
                        .border(1.dp, RogCardBorder, RoundedCornerShape(8.dp))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(RoundedCornerShape(3.dp))
                                .background(RogGreen)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = stats.hardwareModel.take(18),
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary
                        )
                    }
                }
            }
        }

        // Animated circular performance indicators
        item {
            RogCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("hardware_telemetry_card"),
                borderColor = RogCardBorderActive.copy(alpha = 0.5f)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "SYSTEM TELEMETRY",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.sp
                            ),
                            color = RogCyan
                        )
                        Text(
                            text = "${stats.currentRefreshRate.toInt()} HZ DISPLAY",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = RogRed
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Circular Gauges Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RogCircularGauge(
                            percentage = stats.ramUsagePercent,
                            label = "RAM",
                            subLabel = "${stats.usedRamMb}/${stats.totalRamMb} MB",
                            color = if (stats.ramUsagePercent > 80) RogRed else RogCyan,
                            size = 120.dp
                        )

                        val batteryTempLabel = stats.batteryTempCelsius?.let {
                            "${String.format(Locale.US, "%.1f", it)}°C"
                        } ?: "--"
                        RogCircularGauge(
                            percentage = stats.batteryLevel,
                            label = "Battery",
                            subLabel = "$batteryTempLabel ${if (stats.isCharging) "⚡" else ""}",
                            color = if (stats.batteryLevel < 20) RogRed else RogGreen,
                            size = 120.dp
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Storage and CPU breakdown
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Storage: ${stats.totalStorageGb - stats.freeStorageGb}GB / ${stats.totalStorageGb}GB",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary
                        )
                        Text(
                            text = "${stats.cpuCoreCount} Cores (${stats.cpuArchitecture})",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextMuted
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    RogLinearProgressBar(
                        percentage = stats.storageUsagePercent,
                        color = RogPurple
                    )
                }
            }
        }

        // Optimization Alert Feedback if ran
        item {
            AnimatedVisibility(
                visible = optResult != null,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                optResult?.let { result ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF0F2B1D))
                            .border(1.dp, RogGreen, RoundedCornerShape(8.dp))
                            .padding(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = "Optimized",
                                tint = RogGreen,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = result.message,
                                style = MaterialTheme.typography.bodySmall,
                                color = TextPrimary
                            )
                        }
                    }
                }
            }
        }

        // Quick Optimization Button
        item {
            RogButton(
                text = if (isOptimizing) "OPTIMIZING CACHE & RAM..." else "⚡ QUICK OPTIMIZE",
                onClick = { viewModel.runQuickOptimization() },
                enabled = !isOptimizing,
                modifier = Modifier.fillMaxWidth(),
                color = RogRed,
                testTag = "quick_optimize_button"
            )
        }

        // Gaming Mode Selection Section
        item {
            RogHeader(
                title = "Gaming Mode",
                subtitle = "Active device optimization profile"
            )

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                GamingMode.values().forEach { mode ->
                    val isSelected = mode == selectedMode
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isSelected) RogSurface else RogCharcoal)
                            .border(
                                width = if (isSelected) 1.5.dp else 1.dp,
                                color = if (isSelected) RogRed else RogCardBorder,
                                shape = RoundedCornerShape(10.dp)
                            )
                            .clickable { viewModel.setGamingMode(mode) }
                            .padding(14.dp)
                            .testTag("mode_${mode.name.lowercase()}")
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(12.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (isSelected) RogRed else TextMuted)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = mode.title,
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = FontWeight.Bold
                                        ),
                                        color = if (isSelected) TextPrimary else TextSecondary
                                    )
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(if (isSelected) RogRed.copy(alpha = 0.2f) else Color.Transparent)
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = mode.badge,
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Black
                                            ),
                                            color = if (isSelected) RogRed else TextMuted
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = mode.description,
                                    style = MaterialTheme.typography.bodyMedium.copy(fontSize = 12.sp),
                                    color = TextSecondary
                                )
                            }
                        }
                    }
                }
            }
        }

        // Recent Games Card
        item {
            RogHeader(
                title = "Game Library",
                subtitle = "${allGames.size} Games Configured",
                actionIcon = {
                    Text(
                        text = "VIEW ALL >",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = RogCyan
                        ),
                        modifier = Modifier
                            .clickable { onNavigateToLibrary() }
                            .padding(4.dp)
                    )
                }
            )

            if (recentGames.isEmpty()) {
                RogCard(
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.Gamepad,
                            contentDescription = "No games",
                            tint = TextMuted,
                            modifier = Modifier.size(36.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "No games launched yet",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        RogButton(
                            text = "Add Games to Library",
                            onClick = onNavigateToLibrary,
                            color = RogCyan,
                            testTag = "empty_add_games_button"
                        )
                    }
                }
            } else {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(recentGames) { game ->
                        Box(
                            modifier = Modifier
                                .width(140.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(RogCharcoal)
                                .border(1.dp, RogCardBorder, RoundedCornerShape(10.dp))
                                .clickable { onLaunchGame(game.packageName) }
                                .padding(12.dp)
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Box(
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(RogSurface),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Gamepad,
                                        contentDescription = game.appName,
                                        tint = RogRed
                                    )
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = game.appName,
                                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                    color = TextPrimary,
                                    maxLines = 1
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Played ${game.totalPlayCount}x",
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                                    color = TextMuted
                                )
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
