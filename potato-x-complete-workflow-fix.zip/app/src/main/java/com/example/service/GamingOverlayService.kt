package com.example.service

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.PotatoXApplication
import com.example.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Locale

class GamingOverlayService : Service() {

    private val serviceScope = CoroutineScope(Dispatchers.Main + Job())
    private var updateJob: Job? = null

    private var windowManager: WindowManager? = null
    private var floatingView: View? = null
    private var colorTintView: View? = null

    private var sessionStartMillis: Long = 0L
    private var currentColorHex: Long = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as? WindowManager
        createNotificationChannel()
        sessionStartMillis = System.currentTimeMillis()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        if (action == ACTION_STOP_OVERLAY) {
            stopSelf()
            return START_NOT_STICKY
        }

        currentColorHex = intent?.getLongExtra(EXTRA_COLOR_HEX, 0L) ?: 0L

        startForeground(NOTIFICATION_ID, buildNotification())

        if (Settings.canDrawOverlays(this)) {
            setupFloatingHud()
            setupColorTintOverlay(currentColorHex)
        }

        startTelemetryLoop()

        return START_STICKY
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Potato X Gaming HUD",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Live game session performance telemetry"
                setShowBadge(false)
            }
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            nm?.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openPending = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, GamingOverlayService::class.java).apply {
            action = ACTION_STOP_OVERLAY
        }
        val stopPending = PendingIntent.getService(
            this, 1, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("POTATO X — Gaming Session Active")
            .setContentText("Live telemetry HUD running. Tap to open dashboard.")
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentIntent(openPending)
            .addAction(0, "Close HUD", stopPending)
            .setOngoing(true)
            .build()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupFloatingHud() {
        if (floatingView != null) return

        val wm = windowManager ?: return

        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 30
            y = 150
        }

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xDD0A0A0E.toInt())
            setPadding(24, 16, 24, 16)
        }

        val titleView = TextView(this).apply {
            text = "⚡ POTATO X HUD"
            setTextColor(0xFFFF003C.toInt())
            textSize = 12f
            paint.isFakeBoldText = true
        }

        val statsView = TextView(this).apply {
            id = ID_STATS_TEXT
            text = "RAM: --% | Temp: --°C\nTimer: 00:00"
            setTextColor(0xFF00E5FF.toInt())
            textSize = 11f
        }

        container.addView(titleView)
        container.addView(statsView)

        // Drag-to-reposition logic
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f

        container.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = initialX + (event.rawX - initialTouchX).toInt()
                    params.y = initialY + (event.rawY - initialTouchY).toInt()
                    try {
                        wm.updateViewLayout(container, params)
                    } catch (ignored: Exception) {}
                    true
                }
                else -> false
            }
        }

        try {
            wm.addView(container, params)
            floatingView = container
        } catch (ignored: Exception) {}
    }

    private fun setupColorTintOverlay(colorHex: Long) {
        if (colorHex == 0L || colorTintView != null) return
        val wm = windowManager ?: return

        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )

        val tintView = FrameLayout(this).apply {
            setBackgroundColor(colorHex.toInt())
        }

        try {
            wm.addView(tintView, params)
            colorTintView = tintView
        } catch (ignored: Exception) {}
    }

    private fun startTelemetryLoop() {
        updateJob?.cancel()
        val app = application as? PotatoXApplication ?: return
        val statsRepo = app.systemStatsRepository

        updateJob = serviceScope.launch {
            while (isActive) {
                try {
                    val stats = statsRepo.getRealDeviceStats()
                    val elapsedSeconds = (System.currentTimeMillis() - sessionStartMillis) / 1000
                    val minutes = elapsedSeconds / 60
                    val seconds = elapsedSeconds % 60
                    val timerText = String.format(Locale.US, "%02d:%02d", minutes, seconds)

                    val tempStr = stats.batteryTempCelsius?.let { "${String.format(Locale.US, "%.1f", it)}°C" } ?: "--"
                    val content = "RAM: ${stats.ramUsagePercent}% | Temp: $tempStr\nTimer: $timerText"

                    floatingView?.findViewById<TextView>(ID_STATS_TEXT)?.text = content
                } catch (ignored: Exception) {}
                delay(2000L) // Lightweight sampling interval
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        updateJob?.cancel()
        try {
            floatingView?.let { windowManager?.removeView(it) }
            colorTintView?.let { windowManager?.removeView(it) }
        } catch (ignored: Exception) {}
    }

    companion object {
        const val CHANNEL_ID = "potato_x_gaming_hud"
        const val NOTIFICATION_ID = 9001
        const val ACTION_STOP_OVERLAY = "com.example.potatox.STOP_OVERLAY"
        const val EXTRA_COLOR_HEX = "extra_color_hex"
        private const val ID_STATS_TEXT = 1001

        fun start(context: Context, colorHex: Long = 0L) {
            val intent = Intent(context, GamingOverlayService::class.java).apply {
                putExtra(EXTRA_COLOR_HEX, colorHex)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, GamingOverlayService::class.java).apply {
                action = ACTION_STOP_OVERLAY
            }
            context.startService(intent)
        }
    }
}
