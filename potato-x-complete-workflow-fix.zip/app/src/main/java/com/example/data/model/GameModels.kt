package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "games")
data class GameEntity(
    @PrimaryKey val packageName: String,
    val appName: String,
    val isFavorite: Boolean = false,
    val isSuggested: Boolean = false,
    val lastPlayedTimestamp: Long = 0L,
    val totalPlayCount: Int = 0,
    val selectedMode: String = "BALANCED",
    val selectedColorProfile: String = "ORIGINAL",
    val overlayEnabled: Boolean = false,
    val customNotes: String = ""
)

data class InstalledAppInfo(
    val packageName: String,
    val appName: String,
    val isGame: Boolean,
    val isSystemApp: Boolean
)

data class DeviceStats(
    val totalRamMb: Long,
    val usedRamMb: Long,
    val freeRamMb: Long,
    val ramUsagePercent: Int,
    val totalStorageGb: Double,
    val freeStorageGb: Double,
    val storageUsagePercent: Int,
    val batteryLevel: Int,
    val batteryTempCelsius: Float?,
    val batteryVoltageMv: Int,
    val isCharging: Boolean,
    val cpuCoreCount: Int,
    val cpuArchitecture: String,
    val hardwareModel: String,
    val currentRefreshRate: Float,
    val supportedRefreshRates: List<Float>,
    val networkLatencyMs: Int,
    val networkType: String
)

data class GamePresetGuide(
    val gameTitle: String,
    val packageName: String,
    val iconName: String,
    val recommendedGraphics: String,
    val recommendedFps: String,
    val recommendedShadows: String,
    val recommendedResolution: String,
    val generalTips: List<String>
)
