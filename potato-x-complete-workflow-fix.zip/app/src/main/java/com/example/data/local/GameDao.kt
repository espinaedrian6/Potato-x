package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.GameEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface GameDao {
    @Query("SELECT * FROM games ORDER BY isFavorite DESC, lastPlayedTimestamp DESC, appName ASC")
    fun getAllGames(): Flow<List<GameEntity>>

    @Query("SELECT * FROM games WHERE isFavorite = 1 ORDER BY lastPlayedTimestamp DESC")
    fun getFavoriteGames(): Flow<List<GameEntity>>

    @Query("SELECT * FROM games WHERE lastPlayedTimestamp > 0 ORDER BY lastPlayedTimestamp DESC LIMIT 5")
    fun getRecentGames(): Flow<List<GameEntity>>

    @Query("SELECT * FROM games WHERE packageName = :packageName LIMIT 1")
    suspend fun getGameByPackage(packageName: String): GameEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGame(game: GameEntity)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertGames(games: List<GameEntity>)

    @Update
    suspend fun updateGame(game: GameEntity)

    @Delete
    suspend fun deleteGame(game: GameEntity)

    @Query("DELETE FROM games WHERE packageName = :packageName")
    suspend fun deleteByPackage(packageName: String)

    @Query("UPDATE games SET lastPlayedTimestamp = :timestamp, totalPlayCount = totalPlayCount + 1 WHERE packageName = :packageName")
    suspend fun recordGameLaunch(packageName: String, timestamp: Long)

    @Query("UPDATE games SET isFavorite = :isFav WHERE packageName = :packageName")
    suspend fun setFavorite(packageName: String, isFav: Boolean)

    @Query("UPDATE games SET selectedMode = :mode WHERE packageName = :packageName")
    suspend fun updateGameMode(packageName: String, mode: String)

    @Query("UPDATE games SET selectedColorProfile = :color WHERE packageName = :packageName")
    suspend fun updateGameColor(packageName: String, color: String)
}
