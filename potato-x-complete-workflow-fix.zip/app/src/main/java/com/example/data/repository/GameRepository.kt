package com.example.data.repository

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import com.example.data.local.GameDao
import com.example.data.model.GameEntity
import com.example.data.model.GamePresetGuide
import com.example.data.model.InstalledAppInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class GameRepository(
    private val context: Context,
    private val gameDao: GameDao
) {
    val allGames: Flow<List<GameEntity>> = gameDao.getAllGames()
    val favoriteGames: Flow<List<GameEntity>> = gameDao.getFavoriteGames()
    val recentGames: Flow<List<GameEntity>> = gameDao.getRecentGames()

    // Preset guides for popular Android games
    val suggestedPresetGuides: List<GamePresetGuide> = listOf(
        GamePresetGuide(
            gameTitle = "Mobile Legends: Bang Bang",
            packageName = "com.mobile.legends",
            iconName = "mlbb",
            recommendedGraphics = "Smooth (Lowest)",
            recommendedFps = "High / Ultra (if display supports 60Hz without throttling)",
            recommendedShadows = "Off (Saves up to 18% GPU load on Helio G35)",
            recommendedResolution = "Standard HD",
            generalTips = listOf(
                "Disable 'Damage Text' and 'Outline' in in-game settings to reduce particle stutter in team fights.",
                "Turn off 'Creep HP' animations in settings.",
                "Set Graphics to 'Smooth' to prevent thermal throttling on 3GB RAM devices."
            )
        ),
        GamePresetGuide(
            gameTitle = "Call of Duty: Mobile",
            packageName = "com.activision.callofduty.shooter",
            iconName = "codm",
            recommendedGraphics = "Low",
            recommendedFps = "High or Max (framerate takes priority over graphics fidelity)",
            recommendedShadows = "Real-Time Shadows: OFF",
            recommendedResolution = "Standard",
            generalTips = listOf(
                "Set Graphic Quality to 'LOW' and Frame Rate to the highest option the game unlocks.",
                "Disable Depth of Field, Bloom, Ragdoll, and Anti-Aliasing.",
                "Preload shaders in CoDM settings to eliminate mid-match compilation hitches."
            )
        ),
        GamePresetGuide(
            gameTitle = "Roblox",
            packageName = "com.roblox.client",
            iconName = "roblox",
            recommendedGraphics = "Manual Graphics Level 1 - 2",
            recommendedFps = "Automatic (60 FPS cap)",
            recommendedShadows = "Disabled automatically at Level 1",
            recommendedResolution = "Native 720p",
            generalTips = listOf(
                "Open in-game Settings menu -> Graphics Mode -> switch from Automatic to Manual.",
                "Lower the Graphics slider to 1 or 2 bars for stable 60 FPS in dense experiences.",
                "Enable 'Performance Stats' in Roblox settings to inspect real client ping."
            )
        ),
        GamePresetGuide(
            gameTitle = "PUBG MOBILE / BGMI",
            packageName = "com.tencent.ig",
            iconName = "pubg",
            recommendedGraphics = "Smooth",
            recommendedFps = "Extreme / Ultra",
            recommendedShadows = "Disable Shadows",
            recommendedResolution = "Colorful or Soft Style (less contrast stress)",
            generalTips = listOf(
                "Select 'Smooth' graphic style to unlock the maximum frame rate option allowed on your device.",
                "Disable 'Auto-adjust graphics' so the game does not dynamically lower FPS during heat spikes.",
                "Turn off Anti-Aliasing to conserve memory on 3GB RAM phones."
            )
        ),
        GamePresetGuide(
            gameTitle = "Minecraft",
            packageName = "com.mojang.minecraftpe",
            iconName = "minecraft",
            recommendedGraphics = "Fancy Graphics: OFF",
            recommendedFps = "Max Framerate: 60 FPS",
            recommendedShadows = "Beautiful Skies: OFF, Smooth Lighting: OFF",
            recommendedResolution = "Render Distance: 6 - 8 Chunks",
            generalTips = listOf(
                "Set Render Distance to 6 or 8 chunks for smooth chunk generation without frame drops.",
                "Disable Fancy Leaves, Beautiful Skies, and Smooth Lighting in Video settings.",
                "Keep UI Profile on Classic or Pocket to minimize rendering overhead."
            )
        ),
        GamePresetGuide(
            gameTitle = "Garena Free Fire",
            packageName = "com.dts.freefireth",
            iconName = "freefire",
            recommendedGraphics = "Smooth",
            recommendedFps = "High FPS: Normal / High",
            recommendedShadows = "Shadow: OFF",
            recommendedResolution = "Standard",
            generalTips = listOf(
                "Graphics: Smooth is essential for stable gunfights on Helio G35 chipset.",
                "Turn OFF High Res (Normal) and Shadow.",
                "Clear in-game resource cache from the Free Fire download center."
            )
        )
    )

    suspend fun getInstalledLaunchableApps(): List<InstalledAppInfo> = withContext(Dispatchers.IO) {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val resolveInfos = pm.queryIntentActivities(intent, 0)
        val selfPackage = context.packageName

        resolveInfos.mapNotNull { resolveInfo ->
            val pkg = resolveInfo.activityInfo.packageName
            if (pkg == selfPackage) return@mapNotNull null

            val appInfo = try {
                pm.getApplicationInfo(pkg, 0)
            } catch (e: Exception) {
                null
            } ?: return@mapNotNull null

            val appName = resolveInfo.loadLabel(pm).toString()
            val isGameCategory = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                appInfo.category == ApplicationInfo.CATEGORY_GAME
            } else {
                (appInfo.flags and ApplicationInfo.FLAG_IS_GAME) != 0
            }

            // Also check suggested game presets or game keywords
            val isSuggestedMatch = suggestedPresetGuides.any { it.packageName == pkg } ||
                    appName.contains("game", ignoreCase = true) ||
                    appName.contains("legends", ignoreCase = true) ||
                    appName.contains("craft", ignoreCase = true) ||
                    appName.contains("racing", ignoreCase = true) ||
                    appName.contains("fire", ignoreCase = true) ||
                    appName.contains("war", ignoreCase = true)

            InstalledAppInfo(
                packageName = pkg,
                appName = appName,
                isGame = isGameCategory || isSuggestedMatch,
                isSystemApp = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            )
        }.sortedWith(compareBy({ !it.isGame }, { it.appName.lowercase() }))
    }

    suspend fun addGameToLibrary(packageName: String, appName: String, isSuggested: Boolean = false) {
        withContext(Dispatchers.IO) {
            val existing = gameDao.getGameByPackage(packageName)
            if (existing == null) {
                gameDao.insertGame(
                    GameEntity(
                        packageName = packageName,
                        appName = appName,
                        isSuggested = isSuggested,
                        isFavorite = false,
                        selectedMode = "BALANCED",
                        selectedColorProfile = "ORIGINAL"
                    )
                )
            }
        }
    }

    suspend fun removeGameFromLibrary(packageName: String) {
        withContext(Dispatchers.IO) {
            gameDao.deleteByPackage(packageName)
        }
    }

    suspend fun toggleFavorite(packageName: String, isFavorite: Boolean) {
        withContext(Dispatchers.IO) {
            gameDao.setFavorite(packageName, isFavorite)
        }
    }

    suspend fun updateGameMode(packageName: String, mode: String) {
        withContext(Dispatchers.IO) {
            gameDao.updateGameMode(packageName, mode)
        }
    }

    suspend fun updateGameColor(packageName: String, color: String) {
        withContext(Dispatchers.IO) {
            gameDao.updateGameColor(packageName, color)
        }
    }

    suspend fun recordGameLaunch(packageName: String) {
        withContext(Dispatchers.IO) {
            gameDao.recordGameLaunch(packageName, System.currentTimeMillis())
        }
    }

    suspend fun autoSeedSuggestedGamesIfInstalled() = withContext(Dispatchers.IO) {
        val pm = context.packageManager
        for (guide in suggestedPresetGuides) {
            try {
                val appInfo = pm.getApplicationInfo(guide.packageName, 0)
                val label = pm.getApplicationLabel(appInfo).toString()
                addGameToLibrary(guide.packageName, label, isSuggested = true)
            } catch (ignored: PackageManager.NameNotFoundException) {
                // Game not installed, do not force
            }
        }
    }
}
