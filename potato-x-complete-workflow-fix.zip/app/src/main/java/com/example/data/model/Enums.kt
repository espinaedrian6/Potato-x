package com.example.data.model

enum class GamingMode(val title: String, val badge: String, val description: String) {
    BALANCED(
        title = "Balanced Mode",
        badge = "BALANCED",
        description = "Standard system operation. Balanced CPU scheduling and normal battery consumption for everyday gaming."
    ),
    PERFORMANCE(
        title = "Performance Mode",
        badge = "MAX POWER",
        description = "Prioritizes foreground gaming performance, requests Android Performance Hints where supported, and suspends Potato X background telemetry."
    ),
    BATTERY_SAVER(
        title = "Battery Saver",
        badge = "ECO",
        description = "Minimizes monitoring frequency, dims background gauges, and conserves power for extended mobile play sessions."
    ),
    POTATO(
        title = "Potato Mode",
        badge = "POTATO ULTRA",
        description = "Ultra-lightweight profile engineered for 2GB-3GB RAM phones like OPPO A17k. Disables heavy animations, trims background memory, and recommends in-game graphics downgrades for peak smoothness."
    )
}

enum class ColorProfile(val title: String, val colorHex: Long, val description: String) {
    ORIGINAL("Original", 0x00000000, "Natural device colors without overlay filtering."),
    GAMING_RED("Gaming Red", 0x22FF003C, "Enhanced cyber crimson tint for intense action and high-contrast night play."),
    GAMING_BLUE("Gaming Blue", 0x2200E5FF, "Cool electric cyan filter reducing warm glare during long competitive matches."),
    GAMING_PURPLE("Gaming Purple", 0x22A855F7, "ROG neon violet aesthetic offering sharp contrast and distinct visual tone."),
    GAMING_GREEN("Gaming Green", 0x2200E676, "Vibrant tactical green highlighting terrain and foliage visibility in battle royales."),
    WARM("Warm Filter", 0x22FF9100, "Amber blue-light reduction filter to alleviate eye strain in dark environments."),
    COOL("Cool White", 0x224A90E2, "Crisp daylight illumination tint for improved daytime outdoor legibility."),
    HIGH_CONTRAST("High Contrast", 0x33000000, "Darkened contrast vignette to elevate UI text visibility against bright backgrounds."),
    CUSTOM("Custom Profile", 0x22FF0055, "Personalized user-defined color and opacity preference.")
}
