package com.example.data.repository

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import rikka.shizuku.Shizuku

enum class ShizukuStatus {
    NOT_INSTALLED,
    SERVICE_STOPPED,
    PERMISSION_DENIED,
    AUTHORIZED
}

data class ShizukuState(
    val status: ShizukuStatus = ShizukuStatus.NOT_INSTALLED,
    val isAvailable: Boolean = false,
    val isAuthorized: Boolean = false,
    val version: Int = 0,
    val statusMessage: String = "Shizuku not connected — Basic features remain available.",
    val supportedFeatures: List<String> = listOf(
        "Low-overhead System RAM Telemetry",
        "Deep Process Inspection without Root",
        "Hardware Refresh Mode Verification",
        "Accurate Thermal Zone Reporting"
    )
)

class ShizukuManager(private val context: Context) {

    private val _state = MutableStateFlow(ShizukuState())
    val state: StateFlow<ShizukuState> = _state.asStateFlow()

    private val permissionListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        if (requestCode == REQUEST_CODE_SHIZUKU) {
            checkStatus()
        }
    }

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        checkStatus()
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        checkStatus()
    }

    init {
        try {
            Shizuku.addBinderReceivedListener(binderReceivedListener)
            Shizuku.addBinderDeadListener(binderDeadListener)
            Shizuku.addRequestPermissionResultListener(permissionListener)
        } catch (ignored: Throwable) {
            // Shizuku not available on device
        }
        checkStatus()
    }

    fun checkStatus() {
        try {
            val isShizukuInstalled = isAppInstalled("moe.shizuku.privileged.api")

            if (!isShizukuInstalled) {
                _state.value = ShizukuState(
                    status = ShizukuStatus.NOT_INSTALLED,
                    isAvailable = false,
                    isAuthorized = false,
                    statusMessage = "Shizuku not connected — Basic features remain available."
                )
                return
            }

            val isBinderAlive = try {
                Shizuku.pingBinder()
            } catch (t: Throwable) {
                false
            }

            if (!isBinderAlive) {
                _state.value = ShizukuState(
                    status = ShizukuStatus.SERVICE_STOPPED,
                    isAvailable = false,
                    isAuthorized = false,
                    statusMessage = "Shizuku app found, but service is not running. Start it via Wireless Debugging in Shizuku app."
                )
                return
            }

            val version = try {
                Shizuku.getVersion()
            } catch (t: Throwable) {
                0
            }

            val hasPermission = try {
                if (Shizuku.isPreV11()) {
                    false
                } else {
                    Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
                }
            } catch (t: Throwable) {
                false
            }

            if (hasPermission) {
                _state.value = ShizukuState(
                    status = ShizukuStatus.AUTHORIZED,
                    isAvailable = true,
                    isAuthorized = true,
                    version = version,
                    statusMessage = "Shizuku connected & authorized (v$version). Advanced telemetry enabled."
                )
            } else {
                _state.value = ShizukuState(
                    status = ShizukuStatus.PERMISSION_DENIED,
                    isAvailable = true,
                    isAuthorized = false,
                    version = version,
                    statusMessage = "Shizuku is running. Tap 'Request Permission' to enable safe elevated diagnostics."
                )
            }
        } catch (t: Throwable) {
            _state.value = ShizukuState(
                status = ShizukuStatus.NOT_INSTALLED,
                isAvailable = false,
                isAuthorized = false,
                statusMessage = "Shizuku not connected — Basic features remain available."
            )
        }
    }

    fun requestPermission() {
        try {
            if (Shizuku.pingBinder()) {
                if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                    Shizuku.requestPermission(REQUEST_CODE_SHIZUKU)
                }
            }
        } catch (t: Throwable) {
            // Defensive catch
            checkStatus()
        }
    }

    fun openShizukuApp() {
        try {
            val intent = context.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
            } else {
                openShizukuDownload()
            }
        } catch (e: Exception) {
            openShizukuDownload()
        }
    }

    fun openShizukuDownload() {
        try {
            val browserIntent = Intent(
                Intent.ACTION_VIEW,
                Uri.parse("https://shizuku.rikka.app/")
            ).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(browserIntent)
        } catch (ignored: Exception) {}
    }

    private fun isAppInstalled(packageName: String): Boolean {
        return try {
            context.packageManager.getPackageInfo(packageName, 0)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun cleanUp() {
        try {
            Shizuku.removeBinderReceivedListener(binderReceivedListener)
            Shizuku.removeBinderDeadListener(binderDeadListener)
            Shizuku.removeRequestPermissionResultListener(permissionListener)
        } catch (ignored: Throwable) {}
    }

    companion object {
        const val REQUEST_CODE_SHIZUKU = 8192
    }
}
