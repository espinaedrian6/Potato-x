package com.example

import android.app.Application
import com.example.data.local.AppDatabase
import com.example.data.repository.GameRepository
import com.example.data.repository.ShizukuManager
import com.example.data.repository.SystemStatsRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class PotatoXApplication : Application() {

    private val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    val database by lazy { AppDatabase.getDatabase(this) }
    val gameRepository by lazy { GameRepository(this, database.gameDao()) }
    val systemStatsRepository by lazy { SystemStatsRepository(this) }
    val shizukuManager by lazy { ShizukuManager(this) }

    override fun onCreate() {
        super.onCreate()
        // Auto-seed popular installed games into library on initial launch
        applicationScope.launch {
            try {
                gameRepository.autoSeedSuggestedGamesIfInstalled()
            } catch (ignored: Exception) {}
        }
    }
}
